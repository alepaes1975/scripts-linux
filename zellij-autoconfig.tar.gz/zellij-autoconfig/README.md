# Projeto Zellij Auto-Config

Configuração automatizada do **Zellij** para servidores Debian/Ubuntu com layout personalizado e informações do sistema.

## 🚀 Características

- ✅ Instalação automática do Zellij (última versão estável)
- ✅ Layout personalizado com 2 tabs
- ✅ Tab principal dividida em 3 painéis:
  - Painel esquerdo: shell interativo (foco inicial)
  - Painel superior direito: `fastfetch`/`hyfetch`/`neofetch` (informações do sistema com logo ASCII)
  - Painel inferior direito: informações de rede formatadas
- ✅ Auto-start do Zellij ao fazer login
- ✅ Script de informações de rede customizado
- ✅ Tema Catppuccin Mocha pré-configurado
- ✅ Instalação inteligente de dependências (detecta e adapta conforme a distribuição)

## 📦 Instalação

```bash
chmod +x install-zellij.sh
./install-zellij.sh
source ~/.bashrc
```

## 🎨 Personalização

### Modificar Layout

Edite o arquivo: `~/.config/zellij/layouts/default.kdl`

```kdl
// Exemplo: adicionar uma nova tab
tab name="Monitoring" {
    pane split_direction="vertical" {
        pane {
            command "htop"
        }
        pane {
            command "tail"
            args "-f" "/var/log/syslog"
        }
    }
}
```

### Criar Novos Layouts

Você pode criar múltiplos layouts e alternar entre eles:

```bash
# Criar novo layout
vim ~/.config/zellij/layouts/monitoring.kdl

# Iniciar Zellij com layout específico
zellij --layout monitoring
```

### Modificar Script de Rede

O script está em: `~/.local/bin/network-info.sh`

Você pode adicionar mais informações como:
- Estatísticas de tráfego (com `vnstat`)
- Conexões ativas (com `ss` ou `netstat`)
- Firewall status (com `ufw status` ou `iptables -L`)
- IP público (já incluído mas comentado)

### Desabilitar Auto-Start

Edite `~/.bashrc` e mude:
```bash
export ZELLIJ_AUTO_START=false
```

## ⌨️ Atalhos Principais

| Atalho | Ação |
|--------|------|
| `Ctrl+g` | Modo normal (ativa todos os atalhos) |
| `Ctrl+t` | Gerenciar tabs (novo, renomear, fechar) |
| `Ctrl+p` | Gerenciar painéis (dividir, redimensionar, fechar) |
| `Ctrl+s` | Modo scroll (navegar pelo histórico) |
| `Ctrl+o` | Modo sessão (desanexar, sair) |
| `Ctrl+q` | Sair do Zellij |

### Dentro do Modo Tab (Ctrl+t)

- `n` - Nova tab
- `x` - Fechar tab atual
- `r` - Renomear tab
- `1-9` - Ir para tab específica
- `Tab` - Alternar para próxima tab

### Dentro do Modo Pane (Ctrl+p)

- `n` - Novo painel (vertical)
- `d` - Novo painel (horizontal)
- `x` - Fechar painel atual
- `f` - Fullscreen do painel
- `←↓↑→` - Navegar entre painéis
- `z` - Redimensionar painéis

## 🔧 Configurações Avançadas

### Plugins Úteis

O Zellij suporta plugins em WASM. Alguns interessantes:

1. **zellij-forgot** - Exibe atalhos disponíveis
2. **zjstatus** - Status bar customizável
3. **zellij-autolock** - Lock automático após inatividade

Para instalar plugins, adicione no `config.kdl`:

```kdl
plugins {
    compact-bar location="zellij:compact-bar"
}
```

### Sessões Nomeadas

```bash
# Criar sessão específica
zellij -s producao

# Listar sessões
zellij ls

# Anexar a uma sessão
zellij attach producao

# Matar uma sessão
zellij kill-session producao
```

### Multiplexação Remota

O Zellij funciona perfeitamente com SSH:

```bash
ssh servidor "zellij attach -c"
```

Isso permite que você desconecte e reconecte mantendo tudo rodando.

## 🛠️ Troubleshooting

### Zellij não inicia automaticamente

Verifique se a variável está definida:
```bash
echo $ZELLIJ_AUTO_START
```

### Fastfetch não encontrado

O script tentará instalar automaticamente uma das seguintes alternativas:
1. **fastfetch** (preferencial) - via repositório ou binário oficial
2. **hyfetch** (Ubuntu 24.04+) - disponível nos repos oficiais
3. **neofetch** (fallback) - amplamente disponível mas descontinuado

Se nenhum funcionar, instale manualmente:
```bash
# Opção 1: Instalar fastfetch via binário oficial (recomendado)
wget https://github.com/fastfetch-cli/fastfetch/releases/download/2.30.1/fastfetch-linux-amd64.deb
sudo dpkg -i fastfetch-linux-amd64.deb

# Opção 2: Usar hyfetch (Ubuntu 24.04+)
sudo apt install hyfetch
sudo ln -s /usr/bin/hyfetch /usr/local/bin/fastfetch

# Opção 3: Usar neofetch
sudo apt install neofetch
```

### Layout não carrega

Verifique a sintaxe do arquivo KDL:
```bash
zellij --layout ~/.config/zellij/layouts/default.kdl
```

### Cores não aparecem corretamente

Certifique-se que seu terminal suporta true color. Teste:
```bash
echo $COLORTERM
# Deve retornar: truecolor ou 24bit
```

## 📚 Recursos Adicionais

- [Documentação Oficial do Zellij](https://zellij.dev)
- [Zellij GitHub](https://github.com/zellij-org/zellij)
- [Awesome Zellij](https://github.com/zellij-org/awesome-zellij) - Plugins e recursos

## 🔄 Atualização

Para atualizar o Zellij para a versão mais recente:

```bash
./update-zellij.sh
```

## 🗑️ Desinstalação

```bash
./uninstall-zellij.sh
```

## 📝 Notas

- O script de rede não consulta IP público por padrão (evita delay na inicialização)
- O Zellij usa menos memória que tmux (~10MB vs ~20MB)
- Totalmente compatível com suas sessões SSH existentes
- Não conflita com tmux - você pode ter ambos instalados

## 🆚 Zellij vs Tmux

| Característica | Zellij | Tmux |
|----------------|--------|------|
| Linguagem | Rust | C |
| Interface | Moderna, intuitiva | Tradicional |
| Configuração | KDL (simples) | Config própria |
| Plugins | WASM | Shell scripts |
| Performance | Rápido | Rápido |
| Memória | ~10MB | ~20MB |
| Flutuante | Sim | Não nativo |
| Sessões | Sim | Sim |

---

**Dica Pro**: Combine Zellij com `fzf` para busca rápida de comandos e `zoxide` para navegação inteligente de diretórios!
