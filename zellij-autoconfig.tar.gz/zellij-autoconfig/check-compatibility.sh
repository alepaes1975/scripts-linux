#!/bin/bash
#
# Script de verificação de compatibilidade do sistema
# Verifica se o sistema está pronto para instalar o Zellij
#

echo "=================================="
echo "Verificação de Compatibilidade"
echo "=================================="
echo ""

# Cores
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

OK="${GREEN}✓${NC}"
WARN="${YELLOW}⚠${NC}"
FAIL="${RED}✗${NC}"

# Função para verificar comando
check_cmd() {
    if command -v "$1" &>/dev/null; then
        echo -e "$OK $2 encontrado: $(command -v $1)"
        return 0
    else
        echo -e "$WARN $2 não encontrado"
        return 1
    fi
}

# Sistema Operacional
echo "=== Sistema Operacional ==="
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo -e "$OK Nome: $PRETTY_NAME"
    echo -e "$OK ID: $ID"
    echo -e "$OK Versão: $VERSION_ID"
    
    # Verificar compatibilidade
    if [[ "$ID" == "ubuntu" ]] || [[ "$ID" == "debian" ]]; then
        echo -e "$OK Sistema compatível"
    else
        echo -e "$WARN Sistema não testado oficialmente (pode funcionar)"
    fi
else
    echo -e "$FAIL Não foi possível detectar o sistema operacional"
fi
echo ""

# Arquitetura
echo "=== Arquitetura ==="
ARCH=$(uname -m)
echo -e "Arquitetura: $ARCH"
case $ARCH in
    x86_64)
        echo -e "$OK Arquitetura suportada (x86_64)"
        ;;
    aarch64)
        echo -e "$OK Arquitetura suportada (aarch64/ARM64)"
        ;;
    *)
        echo -e "$FAIL Arquitetura não suportada"
        ;;
esac
echo ""

# Kernel
echo "=== Kernel ==="
KERNEL=$(uname -r)
echo -e "$OK Kernel: $KERNEL"
echo ""

# Dependências essenciais
echo "=== Dependências Essenciais ==="
check_cmd "curl" "curl"
check_cmd "tar" "tar"
check_cmd "jq" "jq"
check_cmd "ip" "iproute2"
check_cmd "sudo" "sudo"
echo ""

# Ferramentas de info do sistema
echo "=== Ferramentas de Info do Sistema ==="
SYSINFO_FOUND=false

if check_cmd "fastfetch" "fastfetch"; then
    SYSINFO_FOUND=true
    echo -e "  ${GREEN}→ Recomendado!${NC}"
fi

if check_cmd "hyfetch" "hyfetch"; then
    SYSINFO_FOUND=true
    echo -e "  ${GREEN}→ Alternativa compatível${NC}"
fi

if check_cmd "neofetch" "neofetch"; then
    SYSINFO_FOUND=true
    echo -e "  ${YELLOW}→ Funciona mas foi descontinuado${NC}"
fi

if ! $SYSINFO_FOUND; then
    echo -e "$WARN Nenhuma ferramenta de info do sistema encontrada"
    echo -e "  O script instalará automaticamente a melhor opção"
fi
echo ""

# Gerenciador de pacotes
echo "=== Gerenciador de Pacotes ==="
if check_cmd "apt" "apt"; then
    echo -e "  ${GREEN}→ Compatível com o script de instalação${NC}"
else
    echo -e "$FAIL apt não encontrado (necessário para instalação)"
fi
echo ""

# Verificar espaço em disco
echo "=== Espaço em Disco ==="
AVAIL_SPACE=$(df /tmp --output=avail | tail -1)
AVAIL_MB=$((AVAIL_SPACE / 1024))

if [ $AVAIL_MB -gt 100 ]; then
    echo -e "$OK Espaço disponível em /tmp: ${AVAIL_MB}MB"
else
    echo -e "$WARN Pouco espaço em /tmp: ${AVAIL_MB}MB (recomendado: >100MB)"
fi
echo ""

# Verificar se já existe instalação do Zellij
echo "=== Zellij ==="
if command -v zellij &>/dev/null; then
    CURRENT_VERSION=$(zellij --version | awk '{print $2}')
    echo -e "$OK Zellij já instalado: v$CURRENT_VERSION"
    echo -e "  O script perguntará se deseja reinstalar"
else
    echo -e "$WARN Zellij não instalado"
fi
echo ""

# Verificar se tmux está instalado
echo "=== Multiplexers Existentes ==="
if command -v tmux &>/dev/null; then
    TMUX_VERSION=$(tmux -V)
    echo -e "$OK tmux encontrado: $TMUX_VERSION"
    echo -e "  ${YELLOW}→ Zellij e tmux podem coexistir sem problemas${NC}"
fi

if command -v screen &>/dev/null; then
    echo -e "$OK screen encontrado"
    echo -e "  ${YELLOW}→ Zellij e screen podem coexistir sem problemas${NC}"
fi
echo ""

# Verificar acesso root/sudo
echo "=== Permissões ==="
if [ "$EUID" -eq 0 ]; then
    echo -e "$OK Executando como root"
elif sudo -n true 2>/dev/null; then
    echo -e "$OK Acesso sudo sem senha"
else
    echo -e "$WARN Pode precisar digitar senha sudo durante instalação"
fi
echo ""

# Verificar conectividade
echo "=== Conectividade ==="
if ping -c 1 -W 2 github.com &>/dev/null; then
    echo -e "$OK Acesso à internet OK"
else
    echo -e "$WARN Sem acesso à internet ou github.com bloqueado"
    echo -e "  ${YELLOW}→ Necessário para baixar o Zellij${NC}"
fi
echo ""

# Terminal atual
echo "=== Terminal ==="
echo -e "TERM: $TERM"
if [[ "$COLORTERM" == "truecolor" ]] || [[ "$COLORTERM" == "24bit" ]]; then
    echo -e "$OK True color suportado"
else
    echo -e "$WARN True color pode não estar disponível"
    echo -e "  ${YELLOW}→ Zellij funcionará mas as cores podem não ser ideais${NC}"
fi
echo ""

# Resumo final
echo "=================================="
echo "Resumo da Verificação"
echo "=================================="
echo ""

ISSUES=0

# Verificar problemas críticos
if ! command -v apt &>/dev/null; then
    echo -e "$FAIL Sistema não usa apt (incompatível)"
    ISSUES=$((ISSUES + 1))
fi

if [[ "$ARCH" != "x86_64" ]] && [[ "$ARCH" != "aarch64" ]]; then
    echo -e "$FAIL Arquitetura não suportada"
    ISSUES=$((ISSUES + 1))
fi

if ! command -v curl &>/dev/null; then
    echo -e "$WARN curl não instalado (será instalado automaticamente)"
fi

if ! command -v sudo &>/dev/null && [ "$EUID" -ne 0 ]; then
    echo -e "$FAIL Nem root nem sudo disponível"
    ISSUES=$((ISSUES + 1))
fi

if [ $ISSUES -eq 0 ]; then
    echo -e "${GREEN}✓ Sistema compatível!${NC}"
    echo -e ""
    echo -e "Você pode prosseguir com a instalação:"
    echo -e "  ./install-zellij.sh"
else
    echo -e "${RED}✗ $ISSUES problema(s) crítico(s) encontrado(s)${NC}"
    echo -e ""
    echo -e "Resolva os problemas acima antes de instalar."
fi

echo ""
echo "=================================="
