# Zellij - Guia Rápido de Referência

## 🎯 Conceitos Básicos

O Zellij funciona com **modos**. Cada modo tem seus próprios atalhos:
- Pressione `Ctrl+g` para ativar o modo normal (onde todos os atalhos funcionam)
- Pressione `Esc` ou `Ctrl+g` novamente para voltar ao modo locked

## ⌨️ Atalhos Principais

### Modo Normal (Ctrl+g)
```
Ctrl+g → Modo normal/locked (alterna)
Ctrl+p → Modo painéis
Ctrl+t → Modo tabs
Ctrl+s → Modo scroll
Ctrl+o → Modo sessão
Ctrl+h → Modo mover
Ctrl+q → Sair do Zellij
```

### Gerenciamento de Tabs (Ctrl+t)
```
n     → Nova tab
x     → Fechar tab atual
r     → Renomear tab
1-9   → Ir para tab específica (1, 2, 3...)
Tab   → Próxima tab
h/←   → Tab anterior
l/→   → Próxima tab
[     → Tab anterior
]     → Próxima tab
```

### Gerenciamento de Painéis (Ctrl+p)
```
n     → Novo painel (split vertical)
d     → Novo painel (split horizontal)
x     → Fechar painel atual
f     → Toggle fullscreen
z     → Redimensionar painéis
w     → Toggle flutuante

Navegação:
h/←   → Painel à esquerda
j/↓   → Painel abaixo
k/↑   → Painel acima
l/→   → Painel à direita
```

### Modo Scroll (Ctrl+s)
```
Ctrl+s → Entrar no modo scroll
e      → Editar scrollback no editor
s      → Buscar no scrollback
d      → Rolar meia página para baixo
u      → Rolar meia página para cima
j/↓    → Descer uma linha
k/↑    → Subir uma linha
```

### Modo Sessão (Ctrl+o)
```
d  → Desanexar da sessão (detach)
w  → Listar sessões
c  → Criar sessão nomeada
```

### Modo Redimensionar (Ctrl+h depois do Ctrl+p z)
```
h/← → Diminuir largura
l/→ → Aumentar largura
j/↓ → Diminuir altura
k/↑ → Aumentar altura
+   → Aumentar em todas as direções
-   → Diminuir em todas as direções
```

## 🚀 Comandos CLI

```bash
# Iniciar sessão nova ou anexar à existente
zellij

# Criar sessão nomeada
zellij -s producao

# Anexar a sessão específica
zellij attach producao

# Criar nova sessão mesmo que já exista
zellij attach -c producao

# Listar sessões ativas
zellij list-sessions
zellij ls

# Matar sessão específica
zellij kill-session producao

# Matar todas as sessões
zellij kill-all-sessions

# Usar layout específico
zellij --layout monitoring
zellij -l ~/.config/zellij/layouts/database.kdl

# Executar comando em novo painel
zellij run -- htop
zellij run -f -- tail -f /var/log/syslog  # Em flutuante

# Configuração
zellij setup --dump-config > ~/.config/zellij/config.kdl
zellij setup --check  # Verificar configuração
```

## 📁 Estrutura de Arquivos

```
~/.config/zellij/
├── config.kdl           # Configuração principal
└── layouts/
    ├── default.kdl      # Layout padrão
    ├── monitoring.kdl   # Layout de monitoramento
    ├── database.kdl     # Layout para banco de dados
    └── proxmox.kdl      # Layout para Proxmox
```

## 🎨 Configuração KDL

### Exemplo de Layout Simples
```kdl
layout {
    tab name="Main" {
        pane split_direction="vertical" {
            pane size="50%"  // Painel esquerdo
            pane             // Painel direito
        }
    }
}
```

### Exemplo com Comandos
```kdl
layout {
    tab name="Logs" {
        pane {
            command "tail"
            args "-f" "/var/log/syslog"
        }
    }
}
```

### Template de Tab Personalizado
```kdl
default_tab_template {
    pane size=1 borderless=true {
        plugin location="zellij:tab-bar"
    }
    children
    pane size=2 borderless=true {
        plugin location="zellij:status-bar"
    }
}
```

## 🔧 Truques e Dicas

### Copiar Texto
1. Entre no modo scroll: `Ctrl+g` depois `Ctrl+s`
2. Selecione o texto com o mouse ou modo visual
3. Copie com `Ctrl+Shift+C` ou botão do meio do mouse

### Painéis Flutuantes
- `Ctrl+p` depois `w` → Criar painel flutuante
- `Ctrl+p` depois `e` → Embed painel flutuante
- Útil para comandos temporários!

### Busca no Histórico
1. `Ctrl+s` (modo scroll)
2. `/` para buscar para frente
3. `?` para buscar para trás
4. `n` próximo resultado, `N` anterior

### Múltiplas Sessões
```bash
# Terminal 1
zellij -s web

# Terminal 2
zellij -s db

# Terminal 3
zellij -s monitoring

# Alternar entre elas
zellij ls
zellij attach web
```

### Compartilhar Sessões
```bash
# Usuário 1 cria sessão
zellij -s shared

# Usuário 2 (mesmo servidor) anexa
zellij attach shared
```

### Integração com SSH
```bash
# No .ssh/config
Host servidor
    HostName 192.168.1.100
    RemoteCommand zellij attach -c main

# Ou no bashrc do servidor
[[ -z "$ZELLIJ" ]] && exec zellij attach -c
```

## 🐛 Troubleshooting

### Zellij não responde
```bash
# Ctrl+g + Ctrl+o + d (detach)
# Ou de outro terminal:
zellij kill-session nome-da-sessao
```

### Resetar configuração
```bash
mv ~/.config/zellij ~/.config/zellij.backup
zellij setup --dump-config > ~/.config/zellij/config.kdl
```

### Problemas com cores
```bash
# Verificar suporte a true color
echo $COLORTERM  # Deve ser 'truecolor' ou '24bit'

# Forçar no .bashrc
export COLORTERM=truecolor
```

## 📚 Recursos

- **Docs Oficiais**: https://zellij.dev
- **GitHub**: https://github.com/zellij-org/zellij
- **Discord**: https://discord.gg/zellij
- **Awesome Zellij**: https://github.com/zellij-org/awesome-zellij

## 🆚 Migração do Tmux

| Tmux | Zellij | Descrição |
|------|--------|-----------|
| `Ctrl+b c` | `Ctrl+t n` | Nova window/tab |
| `Ctrl+b %` | `Ctrl+p n` | Split vertical |
| `Ctrl+b "` | `Ctrl+p d` | Split horizontal |
| `Ctrl+b d` | `Ctrl+o d` | Detach |
| `Ctrl+b [` | `Ctrl+s` | Scroll mode |
| `tmux ls` | `zellij ls` | Listar sessões |
| `tmux attach` | `zellij attach` | Anexar sessão |
| `.tmux.conf` | `config.kdl` | Arquivo config |

**Dica**: Você pode usar ambos! Não há conflito de atalhos.

---

**Nota**: Este guia é para Zellij v0.40+. Alguns comandos podem variar em versões anteriores.
