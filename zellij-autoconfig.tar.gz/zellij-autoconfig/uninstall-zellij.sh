#!/bin/bash
#
# Script de desinstalação do Zellij
#

echo "==================================="
echo "Desinstalação do Zellij"
echo "==================================="
echo ""
echo "Este script irá:"
echo "  - Remover o binário do Zellij"
echo "  - Remover configurações (~/.config/zellij)"
echo "  - Remover scripts auxiliares (~/.local/bin/network-info.sh)"
echo "  - Remover auto-start do ~/.bashrc"
echo ""
read -p "Tem certeza que deseja desinstalar? (s/N): " CONFIRM

if [[ ! "$CONFIRM" =~ ^[Ss]$ ]]; then
    echo "Desinstalação cancelada"
    exit 0
fi

# Remover binário
if [ -f /usr/local/bin/zellij ]; then
    echo "Removendo binário..."
    sudo rm /usr/local/bin/zellij
    [ -f /usr/local/bin/zellij.backup ] && sudo rm /usr/local/bin/zellij.backup
fi

# Remover configurações
if [ -d "$HOME/.config/zellij" ]; then
    echo "Removendo configurações..."
    rm -rf "$HOME/.config/zellij"
fi

# Remover scripts
if [ -f "$HOME/.local/bin/network-info.sh" ]; then
    echo "Removendo scripts auxiliares..."
    rm "$HOME/.local/bin/network-info.sh"
fi

# Remover auto-start do bashrc
if [ -f "$HOME/.bashrc" ]; then
    echo "Removendo auto-start do ~/.bashrc..."
    # Criar backup
    cp "$HOME/.bashrc" "$HOME/.bashrc.backup-zellij"
    
    # Remover linhas relacionadas ao Zellij
    sed -i '/# Auto-start Zellij/,/^fi$/d' "$HOME/.bashrc"
    sed -i '/ZELLIJ_AUTO_START/d' "$HOME/.bashrc"
fi

echo ""
echo "==================================="
echo "Desinstalação concluída!"
echo "==================================="
echo ""
echo "Backup do .bashrc salvo em: ~/.bashrc.backup-zellij"
echo ""
echo "Para remover o fastfetch também:"
echo "  sudo apt remove fastfetch"
echo ""
