#!/bin/bash
#
# Script de instalação do Zellij com configuração personalizada
# Compatível com Debian/Ubuntu
#

set -e

ZELLIJ_VERSION="0.40.1"
CONFIG_DIR="$HOME/.config/zellij"
SCRIPTS_DIR="$HOME/.local/bin"

echo "==================================="
echo "Instalação do Zellij"
echo "==================================="

# Detectar arquitetura
ARCH=$(uname -m)
case $ARCH in
    x86_64)
        ZELLIJ_ARCH="x86_64-unknown-linux-musl"
        ;;
    aarch64)
        ZELLIJ_ARCH="aarch64-unknown-linux-musl"
        ;;
    *)
        echo "Arquitetura $ARCH não suportada"
        exit 1
        ;;
esac

# Instalar dependências
echo "Instalando dependências..."
sudo apt update
sudo apt install -y curl tar fastfetch jq iproute2 dnsutils

# Criar diretórios necessários
mkdir -p "$CONFIG_DIR/layouts"
mkdir -p "$SCRIPTS_DIR"

# Verificar se já existe instalação do Zellij
if command -v zellij &> /dev/null; then
    CURRENT_VERSION=$(zellij --version | awk '{print $2}')
    echo "Zellij $CURRENT_VERSION já está instalado"
    read -p "Deseja reinstalar a versão $ZELLIJ_VERSION? (s/N): " REINSTALL
    if [[ ! "$REINSTALL" =~ ^[Ss]$ ]]; then
        echo "Pulando instalação do Zellij"
        SKIP_INSTALL=1
    fi
fi

# Baixar e instalar Zellij
if [[ "$SKIP_INSTALL" != "1" ]]; then
    echo "Baixando Zellij $ZELLIJ_VERSION..."
    cd /tmp
    curl -L "https://github.com/zellij-org/zellij/releases/download/v${ZELLIJ_VERSION}/zellij-${ZELLIJ_ARCH}.tar.gz" -o zellij.tar.gz
    
    echo "Instalando Zellij..."
    tar -xzf zellij.tar.gz
    chmod +x zellij
    sudo mv zellij /usr/local/bin/
    rm zellij.tar.gz
    
    echo "Zellij instalado com sucesso!"
fi

# Criar script de informações de rede
echo "Criando scripts auxiliares..."
cat > "$SCRIPTS_DIR/network-info.sh" << 'NETEOF'
#!/bin/bash

# Cores para formatação
BOLD='\033[1m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${BLUE}              INFORMAÇÕES DE REDE${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}\n"

# Interfaces de rede
echo -e "${BOLD}${GREEN}▶ Interfaces de Rede:${NC}"
ip -brief addr show | grep -v "^lo" | while read -r iface state addr rest; do
    if [[ "$state" == "UP" ]]; then
        state_color="${GREEN}"
        state_symbol="●"
    else
        state_color="${YELLOW}"
        state_symbol="○"
    fi
    echo -e "  ${state_color}${state_symbol}${NC} ${BOLD}$iface${NC} [$state_color$state$NC] → $addr"
done

# Gateway padrão
echo -e "\n${BOLD}${GREEN}▶ Gateway Padrão:${NC}"
ip route show default | awk '{print "  → "$3" via "$5}' | head -1

# Rotas principais
echo -e "\n${BOLD}${GREEN}▶ Rotas Principais:${NC}"
ip route show | grep -v "default" | head -5 | while read -r line; do
    echo "  → $line"
done

# DNS Servers
echo -e "\n${BOLD}${GREEN}▶ Servidores DNS:${NC}"
if [ -f /etc/resolv.conf ]; then
    grep "^nameserver" /etc/resolv.conf | awk '{print "  → "$2}'
else
    echo "  → Arquivo /etc/resolv.conf não encontrado"
fi

# Hostname
echo -e "\n${BOLD}${GREEN}▶ Hostname:${NC}"
echo -e "  → $(hostname -f 2>/dev/null || hostname)"

# IP Público (opcional - comentado por padrão para evitar delay)
# echo -e "\n${BOLD}${GREEN}▶ IP Público:${NC}"
# PUBLIC_IP=$(timeout 2 curl -s ifconfig.me 2>/dev/null || echo "N/A")
# echo -e "  → $PUBLIC_IP"

echo -e "\n${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
NETEOF

chmod +x "$SCRIPTS_DIR/network-info.sh"

# Criar configuração principal do Zellij
echo "Criando configuração do Zellij..."
cat > "$CONFIG_DIR/config.kdl" << 'CONFEOF'
// Configuração do Zellij

// Tema
theme "catppuccin-mocha"

// Keybindings padrão (Ctrl+g para modo normal)
keybinds {
    normal {
        bind "Ctrl g" { SwitchToMode "locked"; }
        bind "Ctrl p" { SwitchToMode "pane"; }
        bind "Ctrl t" { SwitchToMode "tab"; }
        bind "Ctrl s" { SwitchToMode "scroll"; }
        bind "Ctrl o" { SwitchToMode "session"; }
        bind "Ctrl q" { Quit; }
    }
    
    locked {
        bind "Ctrl g" { SwitchToMode "normal"; }
    }
}

// Configurações gerais
default_layout "default"
default_shell "bash"
pane_frames false
simplified_ui true
mouse_mode true
copy_on_select true
scrollback_editor "vim"
mirror_session false

// Configuração do tema Catppuccin
themes {
    catppuccin-mocha {
        bg "#1e1e2e"
        fg "#cdd6f4"
        red "#f38ba8"
        green "#a6e3a1"
        blue "#89b4fa"
        yellow "#f9e2af"
        magenta "#cba6f7"
        orange "#fab387"
        cyan "#89dceb"
        black "#11111b"
        white "#cdd6f4"
    }
}
CONFEOF

# Criar layout personalizado
cat > "$CONFIG_DIR/layouts/default.kdl" << 'LAYOUTEOF'
layout {
    default_tab_template {
        pane size=1 borderless=true {
            plugin location="zellij:tab-bar"
        }
        children
        pane size=2 borderless=true {
            plugin location="zellij:status-bar"
        }
    }

    tab name="Main" focus=true {
        pane split_direction="vertical" {
            // Lado esquerdo - shell normal
            pane size="50%" focus=true
            
            // Lado direito - 2 painéis horizontais com informações
            pane split_direction="horizontal" size="50%" {
                // Painel superior direito - fastfetch
                pane {
                    command "fastfetch"
                }
                
                // Painel inferior direito - informações de rede
                pane {
                    command "bash"
                    args "-c" "$HOME/.local/bin/network-info.sh; exec bash"
                }
            }
        }
    }

    tab name="Work" {
        pane
    }
}
LAYOUTEOF

# Configurar shell para iniciar Zellij automaticamente
echo "Configurando inicialização automática..."

# Adicionar ao bashrc se ainda não existir
if ! grep -q "ZELLIJ_AUTO_START" "$HOME/.bashrc"; then
    cat >> "$HOME/.bashrc" << 'BASHEOF'

# Auto-start Zellij
export ZELLIJ_AUTO_START=true

if [[ -z "$ZELLIJ" ]] && [[ "$ZELLIJ_AUTO_START" == "true" ]]; then
    # Não iniciar se for um comando não-interativo
    if [[ $- == *i* ]]; then
        exec zellij attach -c default
    fi
fi
BASHEOF
    echo "Configuração adicionada ao ~/.bashrc"
fi

# Adicionar PATH se necessário
if ! grep -q "$SCRIPTS_DIR" "$HOME/.bashrc"; then
    echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> "$HOME/.bashrc"
fi

echo ""
echo "==================================="
echo "Instalação concluída!"
echo "==================================="
echo ""
echo "Próximos passos:"
echo "  1. Execute: source ~/.bashrc"
echo "  2. Inicie o Zellij: zellij"
echo "  3. Ou simplesmente abra um novo terminal"
echo ""
echo "Comandos úteis do Zellij:"
echo "  Ctrl+g → Modo normal (ativa todos os atalhos)"
echo "  Ctrl+t → Gerenciar tabs"
echo "  Ctrl+p → Gerenciar painéis"
echo "  Ctrl+s → Modo scroll"
echo "  Ctrl+q → Sair"
echo ""
echo "Configurações em: $CONFIG_DIR"
echo "Layout em: $CONFIG_DIR/layouts/default.kdl"
echo ""
