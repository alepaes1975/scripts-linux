#!/bin/bash
#
# Script de atualização do Zellij
#

set -e

echo "==================================="
echo "Atualização do Zellij"
echo "==================================="

# Verificar versão atual
if ! command -v zellij &> /dev/null; then
    echo "Zellij não está instalado. Use o script install-zellij.sh"
    exit 1
fi

CURRENT_VERSION=$(zellij --version | awk '{print $2}')
echo "Versão atual: $CURRENT_VERSION"

# Buscar última versão no GitHub
echo "Verificando última versão disponível..."
LATEST_VERSION=$(curl -s https://api.github.com/repos/zellij-org/zellij/releases/latest | jq -r '.tag_name' | sed 's/v//')

if [ -z "$LATEST_VERSION" ]; then
    echo "Erro ao buscar última versão"
    exit 1
fi

echo "Última versão: $LATEST_VERSION"

# Comparar versões
if [ "$CURRENT_VERSION" == "$LATEST_VERSION" ]; then
    echo "Você já está na última versão!"
    exit 0
fi

read -p "Deseja atualizar de $CURRENT_VERSION para $LATEST_VERSION? (s/N): " UPDATE
if [[ ! "$UPDATE" =~ ^[Ss]$ ]]; then
    echo "Atualização cancelada"
    exit 0
fi

# Detectar arquitetura
ARCH=$(uname -m)
case $ARCH in
    x86_64)
        ZELLIJ_ARCH="x86_64-unknown-linux-musl"
        ;;
    aarch64)
        ZELLIJ_ARCH="aarch64-unknown-linux-musl"
        ;;
    *)
        echo "Arquitetura $ARCH não suportada"
        exit 1
        ;;
esac

# Fazer backup da versão atual
echo "Fazendo backup da versão atual..."
sudo cp /usr/local/bin/zellij /usr/local/bin/zellij.backup

# Baixar e instalar nova versão
echo "Baixando Zellij $LATEST_VERSION..."
cd /tmp
curl -L "https://github.com/zellij-org/zellij/releases/download/v${LATEST_VERSION}/zellij-${ZELLIJ_ARCH}.tar.gz" -o zellij.tar.gz

echo "Instalando..."
tar -xzf zellij.tar.gz
chmod +x zellij
sudo mv zellij /usr/local/bin/
rm zellij.tar.gz

# Verificar instalação
NEW_VERSION=$(zellij --version | awk '{print $2}')
echo ""
echo "==================================="
echo "Atualização concluída!"
echo "==================================="
echo "Versão anterior: $CURRENT_VERSION"
echo "Versão nova: $NEW_VERSION"
echo ""
echo "Backup da versão anterior salvo em: /usr/local/bin/zellij.backup"
echo ""
echo "Para restaurar a versão anterior (se necessário):"
echo "  sudo mv /usr/local/bin/zellij.backup /usr/local/bin/zellij"
echo ""
