#!/bin/bash
#
# Script avançado de informações de rede
# Versão expandida com mais detalhes para sysadmins
#

# Cores para formatação
BOLD='\033[1m'
DIM='\033[2m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Largura da tela
WIDTH=70

print_header() {
    echo -e "${BOLD}${CYAN}$(printf '═%.0s' $(seq 1 $WIDTH))${NC}"
    echo -e "${BOLD}${BLUE}$(printf '%*s' $(((${#1}+$WIDTH)/2)) "$1")${NC}"
    echo -e "${BOLD}${CYAN}$(printf '═%.0s' $(seq 1 $WIDTH))${NC}\n"
}

print_section() {
    echo -e "${BOLD}${GREEN}▶ $1${NC}"
}

# Função para calcular velocidade de interface
get_interface_speed() {
    local iface=$1
    local speed_file="/sys/class/net/$iface/speed"
    
    if [ -f "$speed_file" ]; then
        local speed=$(cat "$speed_file" 2>/dev/null)
        if [ "$speed" != "-1" ] && [ -n "$speed" ]; then
            echo "${speed}Mbps"
        else
            echo "N/A"
        fi
    else
        echo "N/A"
    fi
}

# Cabeçalho
print_header "INFORMAÇÕES DE REDE"

# Hostname e IP
print_section "Sistema"
HOSTNAME=$(hostname -f 2>/dev/null || hostname)
echo -e "  ${DIM}Hostname:${NC} $HOSTNAME"

# Interfaces de rede
print_section "Interfaces de Rede"
ip -brief addr show | while read -r iface state addr rest; do
    if [[ "$iface" != "lo" ]]; then
        # Status colorido
        if [[ "$state" == "UP" ]]; then
            state_color="${GREEN}"
            state_symbol="●"
        else
            state_color="${YELLOW}"
            state_symbol="○"
        fi
        
        # Velocidade da interface
        speed=$(get_interface_speed "$iface")
        
        # MAC Address
        mac=$(ip link show "$iface" | awk '/link\/ether/ {print $2}')
        
        echo -e "  ${state_color}${state_symbol}${NC} ${BOLD}$iface${NC} [${state_color}$state${NC}] ${DIM}($speed)${NC}"
        echo -e "     ${DIM}IP:${NC} $addr"
        echo -e "     ${DIM}MAC:${NC} $mac"
        
        # MTU
        mtu=$(ip link show "$iface" | awk '/mtu/ {print $5}')
        echo -e "     ${DIM}MTU:${NC} $mtu"
        echo ""
    fi
done

# Gateway padrão
print_section "Gateway Padrão"
default_route=$(ip route show default 2>/dev/null | head -1)
if [ -n "$default_route" ]; then
    gateway=$(echo "$default_route" | awk '{print $3}')
    dev=$(echo "$default_route" | awk '{print $5}')
    echo -e "  ${MAGENTA}→${NC} $gateway ${DIM}via${NC} $dev"
    
    # Ping ao gateway para verificar conectividade
    if ping -c 1 -W 1 "$gateway" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} Gateway alcançável"
    else
        echo -e "  ${RED}✗${NC} Gateway não alcançável"
    fi
else
    echo -e "  ${YELLOW}⚠${NC} Nenhum gateway padrão configurado"
fi
echo ""

# Rotas
print_section "Tabela de Rotas"
ip route show | head -8 | while read -r line; do
    if [[ $line == default* ]]; then
        continue
    fi
    echo -e "  ${MAGENTA}→${NC} $line"
done
echo ""

# DNS Servers
print_section "Servidores DNS"
if [ -f /etc/resolv.conf ]; then
    # DNS primários
    dns_servers=$(grep "^nameserver" /etc/resolv.conf | awk '{print $2}')
    if [ -n "$dns_servers" ]; then
        while IFS= read -r dns; do
            # Testar DNS
            if timeout 1 dig @"$dns" google.com +short &>/dev/null; then
                status="${GREEN}✓${NC}"
            else
                status="${RED}✗${NC}"
            fi
            echo -e "  $status ${MAGENTA}→${NC} $dns"
        done <<< "$dns_servers"
        
        # Domain search
        search=$(grep "^search" /etc/resolv.conf | cut -d' ' -f2-)
        [ -n "$search" ] && echo -e "  ${DIM}Domínios de busca:${NC} $search"
    else
        echo -e "  ${YELLOW}⚠${NC} Nenhum nameserver configurado"
    fi
else
    echo -e "  ${RED}✗${NC} Arquivo /etc/resolv.conf não encontrado"
fi
echo ""

# Conexões ativas
print_section "Conexões Estabelecidas"
CONNECTIONS=$(ss -tn state established 2>/dev/null | tail -n +2 | wc -l)
if [ "$CONNECTIONS" -gt 0 ]; then
    echo -e "  ${CYAN}●${NC} $CONNECTIONS conexões ativas"
    
    # Top 5 destinos
    echo -e "  ${DIM}Top destinos:${NC}"
    ss -tn state established 2>/dev/null | tail -n +2 | \
        awk '{print $4}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -5 | \
        while read count ip; do
            echo -e "    ${MAGENTA}→${NC} $ip ${DIM}($count conexões)${NC}"
        done
else
    echo -e "  ${DIM}Nenhuma conexão estabelecida${NC}"
fi
echo ""

# Portas em escuta
print_section "Portas em Escuta"
LISTENING=$(ss -tln 2>/dev/null | tail -n +2 | wc -l)
echo -e "  ${CYAN}●${NC} $LISTENING portas em escuta"

# Portas comuns
echo -e "  ${DIM}Serviços detectados:${NC}"
ss -tlnp 2>/dev/null | tail -n +2 | awk '{print $4}' | sed 's/.*://' | sort -n | uniq | head -10 | \
    while read port; do
        case $port in
            22) service="SSH" ;;
            80) service="HTTP" ;;
            443) service="HTTPS" ;;
            3306) service="MySQL" ;;
            5432) service="PostgreSQL" ;;
            6379) service="Redis" ;;
            27017) service="MongoDB" ;;
            3000) service="Node/React" ;;
            8080) service="HTTP-Alt" ;;
            9090) service="Prometheus" ;;
            *) service="Unknown" ;;
        esac
        echo -e "    ${MAGENTA}→${NC} :$port ${DIM}($service)${NC}"
    done
echo ""

# Estatísticas de tráfego (se disponível)
if command -v vnstat &>/dev/null; then
    print_section "Tráfego de Rede (Hoje)"
    vnstat --oneline | awk -F';' '{
        printf "  ↓ RX: %s | ↑ TX: %s\n", $4, $5
    }'
    echo ""
fi

# IP Público (opcional - descomentar se desejar)
# print_section "IP Público"
# PUBLIC_IP=$(timeout 2 curl -s ifconfig.me 2>/dev/null)
# if [ -n "$PUBLIC_IP" ]; then
#     echo -e "  ${MAGENTA}→${NC} $PUBLIC_IP"
# else
#     echo -e "  ${YELLOW}⚠${NC} Não foi possível obter IP público"
# fi
# echo ""

# Firewall status
if command -v ufw &>/dev/null; then
    print_section "Firewall (UFW)"
    UFW_STATUS=$(sudo ufw status 2>/dev/null | head -1 | awk '{print $2}')
    if [ "$UFW_STATUS" == "active" ]; then
        echo -e "  ${GREEN}✓${NC} UFW ativo"
    else
        echo -e "  ${YELLOW}○${NC} UFW inativo"
    fi
    echo ""
elif systemctl is-active --quiet firewalld; then
    print_section "Firewall (firewalld)"
    echo -e "  ${GREEN}✓${NC} firewalld ativo"
    echo ""
fi

# Rodapé
echo -e "${BOLD}${CYAN}$(printf '═%.0s' $(seq 1 $WIDTH))${NC}"
echo -e "${DIM}Última atualização: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo -e "${BOLD}${CYAN}$(printf '═%.0s' $(seq 1 $WIDTH))${NC}"
