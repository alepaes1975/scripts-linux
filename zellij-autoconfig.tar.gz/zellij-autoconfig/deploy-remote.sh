#!/bin/bash
#
# Deploy remoto para múltiplos servidores
#

if [ $# -eq 0 ]; then
    echo "Uso: $0 <servidor1> [servidor2] [servidor3] ..."
    echo ""
    echo "Exemplo:"
    echo "  $0 user@192.168.1.100 user@192.168.1.101"
    echo "  $0 prod-web-01 prod-db-01"
    exit 1
fi

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TAR_FILE="/tmp/zellij-autoconfig.tar.gz"

echo "Empacotando projeto..."
cd "$PROJECT_DIR/.."
tar -czf "$TAR_FILE" "$(basename "$PROJECT_DIR")"

for SERVER in "$@"; do
    echo ""
    echo "==================================="
    echo "Deploying para: $SERVER"
    echo "==================================="
    
    # Copiar arquivo
    scp "$TAR_FILE" "$SERVER:/tmp/" || {
        echo "Erro ao copiar para $SERVER"
        continue
    }
    
    # Extrair e instalar
    ssh "$SERVER" << 'REMOTEEOF'
        cd /tmp
        tar -xzf zellij-autoconfig.tar.gz
        cd zellij-autoconfig
        
        echo "Iniciando instalação..."
        ./install-zellij.sh
        
        echo "Limpando arquivos temporários..."
        cd ..
        rm -rf zellij-autoconfig zellij-autoconfig.tar.gz
REMOTEEOF
    
    echo "Deploy concluído em $SERVER"
done

rm -f "$TAR_FILE"
echo ""
echo "==================================="
echo "Deploy finalizado!"
echo "==================================="
